"""CloudEMS energy management package."""
